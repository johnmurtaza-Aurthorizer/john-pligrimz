import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Hajj Packages', path: '/hajj-packages' },
    { name: 'Umrah Packages', path: '/umrah-packages' },
    { name: 'Services', path: '/services' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-emerald/95 backdrop-blur-md shadow-soft py-3'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="container-custom">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gold flex items-center justify-center">
                <span className="text-emerald font-playfair font-bold text-lg">AM</span>
              </div>
              <div className="hidden sm:block">
                <span className={`font-playfair font-semibold text-lg leading-tight transition-colors ${
                  isScrolled ? 'text-cream' : 'text-cream'
                }`}>
                  Al Mouood
                </span>
                <span className={`block text-xs transition-colors ${
                  isScrolled ? 'text-cream/70' : 'text-cream/70'
                }`}>
                  Pilgrims
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`text-sm font-medium transition-all duration-300 relative ${
                    isScrolled ? 'text-cream/90' : 'text-cream/90'
                  } hover:text-gold ${
                    isActive(link.path) ? 'text-gold' : ''
                  }`}
                >
                  {link.name}
                  <span
                    className={`absolute -bottom-1 left-0 h-0.5 bg-gold transition-all duration-300 ${
                      isActive(link.path) ? 'w-full' : 'w-0 hover:w-full'
                    }`}
                  />
                </Link>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden lg:flex items-center gap-4">
              <a
                href="tel:+923352200014"
                className="flex items-center gap-2 text-cream/90 hover:text-gold transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span className="text-sm">+92 335 2200014</span>
              </a>
              <Link
                to="/contact"
                className="bg-gold text-emerald px-6 py-2.5 rounded-full text-sm font-medium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
              >
                Book a Call
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-cream"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 lg:hidden transition-all duration-500 ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="absolute inset-0 bg-emerald/98 backdrop-blur-lg" />
        <div className="relative h-full flex flex-col items-center justify-center gap-6 p-8">
          {navLinks.map((link, index) => (
            <Link
              key={link.path}
              to={link.path}
              className={`text-2xl font-playfair text-cream hover:text-gold transition-all duration-300 ${
                isActive(link.path) ? 'text-gold' : ''
              }`}
              style={{
                animationDelay: `${index * 50}ms`,
              }}
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/contact"
            className="mt-6 bg-gold text-emerald px-8 py-3 rounded-full font-medium"
          >
            Book a Call
          </Link>
        </div>
      </div>
    </>
  );
};

export default Navbar;
