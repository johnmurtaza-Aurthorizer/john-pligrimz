import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const image = imageRef.current;
    const headline = headlineRef.current;
    const subheadline = subheadlineRef.current;
    const cta = ctaRef.current;

    if (!section || !content || !image || !headline || !subheadline || !cta) return;

    const ctx = gsap.context(() => {
      // Initial load animation
      const loadTl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      loadTl
        .fromTo(image, 
          { opacity: 0, scale: 1.06 }, 
          { opacity: 1, scale: 1, duration: 1.1 }
        )
        .fromTo(headline.querySelectorAll('.word'),
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.9, stagger: 0.06 },
          '-=0.6'
        )
        .fromTo(subheadline,
          { y: 14, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6 },
          '-=0.4'
        )
        .fromTo(cta,
          { scale: 0.96, opacity: 0 },
          { scale: 1, opacity: 1, duration: 0.5 },
          '-=0.3'
        );

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set(content, { y: 0, opacity: 1 });
            gsap.set(image, { scale: 1, y: 0 });
          }
        }
      });

      // SETTLE phase (0% - 70%): content stays static
      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(content,
          { y: 0, opacity: 1 },
          { y: '-10vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(image,
          { scale: 1, y: 0 },
          { scale: 1.08, y: '-4vh', ease: 'power2.in' },
          0.7
        );

    }, section);

    return () => ctx.revert();
  }, []);

  const headlineWords = "Your Trusted Partner for Hajj & Umrah Journeys".split(' ');

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen overflow-hidden z-10"
    >
      {/* Background Image */}
      <div
        ref={imageRef}
        className="absolute inset-0 z-[1]"
        style={{ opacity: 0 }}
      >
        <img
          src="/images/hero-kaaba.jpg"
          alt="Kaaba in Makkah"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-emerald/35" />
        {/* Vignette */}
        <div 
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at center, transparent 0%, rgba(11,77,60,0.4) 100%)'
          }}
        />
      </div>

      {/* Geometric Pattern Overlay */}
      <div className="geometric-pattern z-[3]" />

      {/* Content */}
      <div
        ref={contentRef}
        className="relative z-[4] h-full flex flex-col items-center justify-center px-4"
      >
        <div className="text-center max-w-4xl mx-auto">
          {/* Headline */}
          <h1
            ref={headlineRef}
            className="heading-xl text-cream mb-6"
          >
            {headlineWords.map((word, index) => (
              <span key={index} className="word inline-block mr-[0.3em]">
                {word}
              </span>
            ))}
          </h1>

          {/* Subheadline */}
          <p
            ref={subheadlineRef}
            className="text-lg md:text-xl text-cream/90 mb-8 max-w-2xl mx-auto"
            style={{ opacity: 0 }}
          >
            Serving pilgrims with comfort, care, and complete guidance.
          </p>

          {/* CTA Buttons */}
          <div
            ref={ctaRef}
            className="flex flex-col sm:flex-row gap-4 justify-center mb-6"
            style={{ opacity: 0 }}
          >
            <Link to="/hajj-packages" className="btn-primary">
              Explore Packages
            </Link>
            <Link to="/contact" className="btn-secondary">
              Contact Us
            </Link>
          </div>

          {/* Trust Line */}
          <p className="text-sm text-cream/70">
            Based in Karachi · Serving families across Pakistan
          </p>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-6 h-6 text-cream/60" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
