import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const FeatureComfortSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imagePanelRef = useRef<HTMLDivElement>(null);
  const textPanelRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const imagePanel = imagePanelRef.current;
    const textPanel = textPanelRef.current;
    const content = contentRef.current;

    if (!section || !imagePanel || !textPanel || !content) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 22%)
      scrollTl
        .fromTo(imagePanel,
          { x: '-60vw', opacity: 1 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(textPanel,
          { x: '60vw', opacity: 1 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(content.children,
          { y: 22, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.02, ease: 'none' },
          0.1
        );

      // SETTLE (22% - 70%): hold

      // EXIT (70% - 100%)
      scrollTl
        .to(imagePanel,
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .to(textPanel,
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-dark w-full h-screen overflow-hidden z-30"
    >
      <div className="geometric-pattern" />
      
      <div className="relative z-10 flex h-full">
        {/* Left Image Panel */}
        <div
          ref={imagePanelRef}
          className="hidden lg:block w-[55vw] h-full relative"
          style={{ transform: 'translateX(-60vw)' }}
        >
          <img
            src="/images/feature-comfort.jpg"
            alt="Comfortable hotel accommodation"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-emerald/30" />
        </div>

        {/* Right Text Panel */}
        <div
          ref={textPanelRef}
          className="w-full lg:w-[45vw] h-full flex items-center justify-center px-8 lg:px-12"
          style={{ transform: 'translateX(60vw)' }}
        >
          <div ref={contentRef} className="max-w-md">
            {/* Mobile Image */}
            <div className="lg:hidden mb-8 rounded-xl overflow-hidden">
              <img
                src="/images/feature-comfort.jpg"
                alt="Comfortable hotel accommodation"
                className="w-full h-48 object-cover"
              />
            </div>

            {/* Label */}
            <span className="label-uppercase block mb-4">Comfort & Care</span>

            {/* Headline */}
            <h2 className="heading-md text-cream mb-6">
              Comfort That Honors Your Journey
            </h2>

            {/* Body */}
            <p className="body-text text-cream/80 mb-8">
              From airport meet-and-greet to hotel check-ins and daily briefings, 
              our team stays with you—so your energy stays where it belongs.
            </p>

            {/* CTA */}
            <Link
              to="/services"
              className="inline-flex items-center gap-2 text-gold hover:text-gold-light transition-colors group"
            >
              <span className="font-medium">See how we support pilgrims</span>
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeatureComfortSection;
