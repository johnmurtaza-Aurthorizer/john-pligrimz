import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface PackageCardProps {
  image: string;
  title: string;
  description: string;
  features: string[];
  price: string;
  delay: number;
}

const PackageCard = ({ image, title, description, features, price, delay }: PackageCardProps) => {
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(card,
        { y: 40, scale: 0.98, opacity: 0 },
        {
          y: 0,
          scale: 1,
          opacity: 1,
          duration: 0.8,
          delay: delay * 0.12,
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          }
        }
      );

      // Parallax for image
      const img = card.querySelector('img');
      if (img) {
        gsap.fromTo(img,
          { y: -18, scale: 1.06 },
          {
            y: 18,
            scale: 1.06,
            scrollTrigger: {
              trigger: card,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true,
            }
          }
        );
      }
    }, card);

    return () => ctx.revert();
  }, [delay]);

  return (
    <div
      ref={cardRef}
      className="bg-cream rounded-xl overflow-hidden shadow-card card-hover"
    >
      {/* Image */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-emerald/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="p-6">
        <h3 className="font-playfair font-semibold text-xl text-emerald mb-2">
          {title}
        </h3>
        <p className="text-emerald/70 text-sm mb-4">
          {description}
        </p>

        {/* Features */}
        <ul className="space-y-2 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center gap-2 text-sm text-emerald/80">
              <Check className="w-4 h-4 text-gold flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>

        {/* Price */}
        <div className="flex items-center justify-between mb-4">
          <span className="text-gold font-semibold">{price}</span>
          <span className="text-xs text-emerald/50">per person</span>
        </div>

        {/* CTA */}
        <Link
          to="/contact"
          className="w-full inline-flex items-center justify-center gap-2 bg-emerald text-cream py-3 rounded-full text-sm font-medium hover:bg-emerald-light transition-colors"
        >
          Request Details
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};

const PackagesSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;

    if (!section || !heading) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(heading,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: heading,
            start: 'top 75%',
            end: 'top 55%',
            scrub: true,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const packages = [
    {
      image: '/images/package-economy.jpg',
      title: 'Economy Package',
      description: 'Essential support for budget-conscious pilgrims.',
      features: [
        '3-star hotel accommodation',
        'Shared transport',
        'Visa processing',
        'Group guidance',
      ],
      price: 'PKR 450,000',
    },
    {
      image: '/images/package-standard.jpg',
      title: 'Standard Package',
      description: 'Balanced comfort with preferred hotels.',
      features: [
        '4-star hotel near Haram',
        'Semi-private transport',
        'Visa & flights included',
        'Daily guidance',
      ],
      price: 'PKR 650,000',
    },
    {
      image: '/images/package-vip.jpg',
      title: 'VIP Package',
      description: 'Premium proximity, private transport, dedicated guide.',
      features: [
        '5-star hotel walking distance',
        'Private air-conditioned transport',
        'Dedicated personal guide',
        'Premium ziyarat tours',
      ],
      price: 'PKR 950,000',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="section-light py-20 lg:py-28 z-40"
    >
      <div className="container-custom">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16">
          <span className="label-uppercase block mb-4">Packages</span>
          <h2 className="heading-lg text-emerald mb-4">
            Packages Built for Families
          </h2>
          <p className="body-text text-emerald/70 max-w-xl mx-auto">
            Transparent pricing. Clear inclusions. No surprises.
          </p>
        </div>

        {/* Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {packages.map((pkg, index) => (
            <PackageCard
              key={pkg.title}
              {...pkg}
              delay={index}
            />
          ))}
        </div>

        {/* View All CTA */}
        <div className="text-center mt-12">
          <Link
            to="/hajj-packages"
            className="inline-flex items-center gap-2 text-emerald font-medium hover:text-gold transition-colors group"
          >
            <span>View All Packages</span>
            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PackagesSection;
