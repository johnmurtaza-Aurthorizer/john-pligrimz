import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MessageSquare, FileText, Plane, Car, HeartHandshake } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const ProcessSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const timeline = timelineRef.current;
    const line = lineRef.current;

    if (!section || !heading || !timeline || !line) return;

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(heading,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: heading,
            start: 'top 80%',
            end: 'top 60%',
            scrub: true,
          }
        }
      );

      // Timeline line animation
      gsap.fromTo(line,
        { scaleX: 0 },
        {
          scaleX: 1,
          scrollTrigger: {
            trigger: timeline,
            start: 'top 75%',
            end: 'top 40%',
            scrub: true,
          }
        }
      );

      // Step items animation
      const steps = timeline.querySelectorAll('.process-step');
      steps.forEach((step, index) => {
        gsap.fromTo(step,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            delay: index * 0.08,
            scrollTrigger: {
              trigger: timeline,
              start: 'top 70%',
              end: 'top 40%',
              scrub: true,
            }
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const steps = [
    {
      icon: MessageSquare,
      title: 'Consultation',
      description: 'Understand your needs, dates, and preferences.',
    },
    {
      icon: FileText,
      title: 'Documentation',
      description: 'Passport, photos, medical—clear checklist.',
    },
    {
      icon: Plane,
      title: 'Visa & Flights',
      description: 'We process visa and confirm tickets.',
    },
    {
      icon: Car,
      title: 'Travel',
      description: 'Airport support, transfers, hotel check-in.',
    },
    {
      icon: HeartHandshake,
      title: 'Guided Support',
      description: 'Daily briefings, ziyarat, and 24/7 care.',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="section-dark py-20 lg:py-28 z-50"
    >
      <div className="geometric-pattern" />
      
      <div className="container-custom relative z-10">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16">
          <span className="label-uppercase block mb-4">Our Process</span>
          <h2 className="heading-lg text-cream mb-4">
            Your Journey, Step by Step
          </h2>
        </div>

        {/* Timeline */}
        <div ref={timelineRef} className="relative">
          {/* Timeline Line (Desktop) */}
          <div
            ref={lineRef}
            className="hidden lg:block absolute top-16 left-[10%] right-[10%] h-0.5 bg-gold/30"
            style={{ transformOrigin: 'left', transform: 'scaleX(0)' }}
          />

          {/* Steps Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-6">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.title}
                  className="process-step text-center"
                >
                  {/* Icon Circle */}
                  <div className="relative inline-flex items-center justify-center w-16 h-16 rounded-full bg-gold/20 border-2 border-gold mb-6 mx-auto">
                    <Icon className="w-7 h-7 text-gold" />
                    {/* Step Number */}
                    <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-gold text-emerald text-xs font-bold flex items-center justify-center">
                      {index + 1}
                    </span>
                  </div>

                  {/* Content */}
                  <h3 className="font-playfair font-semibold text-lg text-cream mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-cream/70">
                    {step.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
