import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const TestimonialsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const cards = cardsRef.current;

    if (!section || !heading || !cards) return;

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(heading,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: heading,
            start: 'top 80%',
            end: 'top 60%',
            scrub: true,
          }
        }
      );

      // Cards animation
      const cardElements = cards.querySelectorAll('.testimonial-card');
      cardElements.forEach((card, index) => {
        gsap.fromTo(card,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            delay: index * 0.08,
            scrollTrigger: {
              trigger: cards,
              start: 'top 75%',
              end: 'top 50%',
              scrub: true,
            }
          }
        );

        // Subtle parallax
        gsap.fromTo(card,
          { y: -10 },
          {
            y: 10,
            scrollTrigger: {
              trigger: card,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true,
            }
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const testimonials = [
    {
      quote: "Al Mouood made our family Umrah smooth from day one. The team was always available and handled everything professionally.",
      name: "A. R.",
      location: "Karachi",
    },
    {
      quote: "Professional, respectful, and always available. They truly understand the spiritual significance of the journey.",
      name: "S. K.",
      location: "Lahore",
    },
    {
      quote: "We felt supported every step of the way. The guidance and care exceeded our expectations.",
      name: "F. M.",
      location: "Islamabad",
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="section-light py-20 lg:py-28 z-[70]"
    >
      <div className="container-custom">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16">
          <h2 className="heading-lg text-emerald mb-4">
            What Pilgrims Say
          </h2>
          <p className="body-text text-emerald/70 max-w-xl mx-auto">
            Hear from families who have journeyed with us.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="testimonial-card bg-cream border-t-2 border-gold p-8 rounded-xl shadow-soft"
            >
              {/* Quote Icon */}
              <Quote className="w-10 h-10 text-gold/30 mb-4" />

              {/* Quote Text */}
              <p className="text-emerald/80 mb-6 leading-relaxed">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald/10 flex items-center justify-center">
                  <span className="text-emerald font-semibold text-sm">
                    {testimonial.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <div>
                  <p className="font-medium text-emerald">{testimonial.name}</p>
                  <p className="text-sm text-emerald/60">{testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
