import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const StatementSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const ruleRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const rule = ruleRef.current;
    const headline = headlineRef.current;
    const body = bodyRef.current;
    const cta = ctaRef.current;

    if (!section || !rule || !headline || !body || !cta) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(rule,
          { scaleX: 0, opacity: 0 },
          { scaleX: 1, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(headline.querySelectorAll('.word'),
          { y: 28, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.02, ease: 'none' },
          0.05
        )
        .fromTo(body,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.12
        )
        .fromTo(cta,
          { y: 14, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.18
        );

      // SETTLE (30% - 70%): hold

      // EXIT (70% - 100%)
      scrollTl
        .to(headline,
          { y: '-8vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .to(body,
          { opacity: 0, ease: 'power2.in' },
          0.75
        )
        .to(cta,
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.72
        )
        .to(rule,
          { opacity: 0, ease: 'power2.in' },
          0.78
        );

    }, section);

    return () => ctx.revert();
  }, []);

  const headlineWords = "A Journey of Peace, Purpose & Spiritual Renewal".split(' ');

  return (
    <section
      ref={sectionRef}
      className="section-dark w-full h-screen flex items-center justify-center z-20"
    >
      <div className="geometric-pattern" />
      
      <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
        {/* Accent Rule */}
        <div
          ref={ruleRef}
          className="w-[72px] h-[2px] bg-gold mx-auto mb-8"
          style={{ transformOrigin: 'center', transform: 'scaleX(0)' }}
        />

        {/* Headline */}
        <h2
          ref={headlineRef}
          className="heading-lg text-cream mb-8"
        >
          {headlineWords.map((word, index) => (
            <span key={index} className="word inline-block mr-[0.25em]">
              {word}
            </span>
          ))}
        </h2>

        {/* Body */}
        <p
          ref={bodyRef}
          className="body-text text-cream/80 mb-10 max-w-2xl mx-auto"
        >
          We handle every detail—visa, flights, hotels, and guided support—so you can 
          focus on what truly matters: your ibadah and your family.
        </p>

        {/* CTA Buttons */}
        <div
          ref={ctaRef}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Link to="/umrah-packages" className="btn-primary">
            View Packages
          </Link>
          <Link to="/contact" className="btn-secondary">
            Contact Us
          </Link>
        </div>
      </div>
    </section>
  );
};

export default StatementSection;
