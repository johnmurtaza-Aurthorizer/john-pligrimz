import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Phone, Clock, MessageCircle, Send } from 'lucide-react';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

const ContactCTASection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const leftColRef = useRef<HTMLDivElement>(null);
  const formCardRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });

  useEffect(() => {
    const section = sectionRef.current;
    const leftCol = leftColRef.current;
    const formCard = formCardRef.current;

    if (!section || !leftCol || !formCard) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(leftCol,
        { x: -40, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            end: 'top 50%',
            scrub: true,
          }
        }
      );

      gsap.fromTo(formCard,
        { x: 40, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            end: 'top 50%',
            scrub: true,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Thank you! We will contact you within 24 hours.');
    setFormData({ name: '', phone: '', email: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const whatsappUrl = `https://wa.me/+923352200014?text=${encodeURIComponent('Assalamualaikum! I would like to inquire about your Hajj/Umrah packages.')}`;

  return (
    <section
      ref={sectionRef}
      className="section-dark py-20 lg:py-28 z-[80]"
    >
      <div className="geometric-pattern" />
      
      <div className="container-custom relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column - Info */}
          <div ref={leftColRef}>
            <span className="label-uppercase block mb-4">Get in Touch</span>
            <h2 className="heading-lg text-cream mb-6">
              Start Your Journey
            </h2>
            <p className="body-text text-cream/80 mb-8">
              Tell us your preferred dates and package. We'll reply within 24 hours.
            </p>

            {/* Contact Details */}
            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-gold flex-shrink-0 mt-1" />
                <span className="text-cream/80 text-sm">
                  G-03, Al-Najaf Arcade, Soldier Bazaar Garden East, Karachi
                </span>
              </div>
              <div className="flex items-center gap-4">
                <Phone className="w-5 h-5 text-gold flex-shrink-0" />
                <a href="tel:+923352200014" className="text-cream/80 hover:text-gold transition-colors text-sm">
                  +92 335 2200014
                </a>
              </div>
              <div className="flex items-center gap-4">
                <Clock className="w-5 h-5 text-gold flex-shrink-0" />
                <span className="text-cream/80 text-sm">
                  Opens 11 AM - Mon to Sat
                </span>
              </div>
            </div>

            {/* WhatsApp CTA */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-green-500 text-white px-6 py-3 rounded-full font-medium hover:bg-green-600 transition-all duration-300 hover:-translate-y-0.5"
            >
              <MessageCircle className="w-5 h-5" />
              Message on WhatsApp
            </a>
          </div>

          {/* Right Column - Form */}
          <div
            ref={formCardRef}
            className="bg-cream rounded-2xl p-8 shadow-card"
          >
            <h3 className="font-playfair font-semibold text-xl text-emerald mb-6">
              Send an Inquiry
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-emerald mb-2">
                  Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald placeholder:text-emerald/40 focus:outline-none focus:border-gold transition-colors"
                  placeholder="Your full name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-emerald mb-2">
                  Phone
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald placeholder:text-emerald/40 focus:outline-none focus:border-gold transition-colors"
                  placeholder="+92 3XX XXXXXXX"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-emerald mb-2">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald placeholder:text-emerald/40 focus:outline-none focus:border-gold transition-colors"
                  placeholder="your@email.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-emerald mb-2">
                  Message
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald placeholder:text-emerald/40 focus:outline-none focus:border-gold transition-colors resize-none"
                  placeholder="Tell us about your preferred package and dates..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gold text-emerald py-3 rounded-full font-medium flex items-center justify-center gap-2 hover:bg-gold-dark transition-colors"
              >
                <Send className="w-4 h-4" />
                Send Inquiry
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactCTASection;
