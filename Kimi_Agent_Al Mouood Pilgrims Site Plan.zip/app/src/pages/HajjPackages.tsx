import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Bed, Bus, FileText, Users, Calendar, ArrowRight, Star } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface PackageDetailProps {
  name: string;
  description: string;
  price: string;
  duration: string;
  image: string;
  hotel: string;
  transport: string;
  features: string[];
  popular?: boolean;
}

const PackageCard = ({ pkg, index }: { pkg: PackageDetailProps; index: number }) => {
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(card,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          delay: index * 0.1,
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          }
        }
      );
    }, card);

    return () => ctx.revert();
  }, [index]);

  return (
    <div
      ref={cardRef}
      className={`bg-cream rounded-2xl overflow-hidden shadow-card ${
        pkg.popular ? 'ring-2 ring-gold' : ''
      }`}
    >
      {/* Image */}
      <div className="relative h-56 overflow-hidden">
        <img
          src={pkg.image}
          alt={pkg.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-emerald/60 to-transparent" />
        
        {/* Popular Badge */}
        {pkg.popular && (
          <div className="absolute top-4 right-4 bg-gold text-emerald px-4 py-1 rounded-full text-sm font-medium flex items-center gap-1">
            <Star className="w-4 h-4" />
            Most Popular
          </div>
        )}

        {/* Price Tag */}
        <div className="absolute bottom-4 left-4">
          <span className="text-cream/80 text-sm">Starting from</span>
          <p className="text-2xl font-playfair font-bold text-gold">{pkg.price}</p>
        </div>
      </div>

      {/* Content */}
      <div className="p-8">
        <div className="flex items-center gap-2 text-emerald/60 text-sm mb-3">
          <Calendar className="w-4 h-4" />
          <span>{pkg.duration}</span>
        </div>

        <h3 className="font-playfair font-semibold text-2xl text-emerald mb-3">
          {pkg.name}
        </h3>
        <p className="text-emerald/70 mb-6">
          {pkg.description}
        </p>

        {/* Details Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald/10 flex items-center justify-center flex-shrink-0">
              <Bed className="w-5 h-5 text-emerald" />
            </div>
            <div>
              <p className="font-medium text-emerald text-sm">Hotel</p>
              <p className="text-emerald/60 text-sm">{pkg.hotel}</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald/10 flex items-center justify-center flex-shrink-0">
              <Bus className="w-5 h-5 text-emerald" />
            </div>
            <div>
              <p className="font-medium text-emerald text-sm">Transport</p>
              <p className="text-emerald/60 text-sm">{pkg.transport}</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald/10 flex items-center justify-center flex-shrink-0">
              <FileText className="w-5 h-5 text-emerald" />
            </div>
            <div>
              <p className="font-medium text-emerald text-sm">Visa</p>
              <p className="text-emerald/60 text-sm">Included</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald/10 flex items-center justify-center flex-shrink-0">
              <Users className="w-5 h-5 text-emerald" />
            </div>
            <div>
              <p className="font-medium text-emerald text-sm">Guidance</p>
              <p className="text-emerald/60 text-sm">Group leader</p>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="border-t border-emerald/10 pt-6 mb-6">
          <p className="font-medium text-emerald mb-3 text-sm">What's Included:</p>
          <ul className="space-y-2">
            {pkg.features.map((feature, idx) => (
              <li key={idx} className="flex items-center gap-2 text-sm text-emerald/70">
                <Check className="w-4 h-4 text-gold flex-shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* CTA */}
        <Link
          to="/contact"
          className="w-full inline-flex items-center justify-center gap-2 bg-emerald text-cream py-3 rounded-full font-medium hover:bg-emerald-light transition-colors"
        >
          Book Now
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};

const HajjPackages = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const hero = heroRef.current;
    if (!hero) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(hero.querySelectorAll('.animate-item'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          duration: 0.8,
          ease: 'power2.out',
        }
      );
    });

    return () => ctx.revert();
  }, []);

  const packages: PackageDetailProps[] = [
    {
      name: 'Economy Package',
      description: 'Essential support for budget-conscious pilgrims without compromising on the essentials.',
      price: 'PKR 850,000',
      duration: '35-40 Days',
      image: '/images/package-economy.jpg',
      hotel: '3-star, 4-5km from Haram',
      transport: 'Shared AC bus',
      features: [
        'Hajj visa processing',
        'Return flights from Karachi',
        'Makkah & Madinah accommodation',
        'Daily meals (breakfast & dinner)',
        'Group guidance throughout',
        'Ziyarat tours in both cities',
        '24/7 emergency support',
      ],
    },
    {
      name: 'Standard Package',
      description: 'Balanced comfort with preferred hotels and enhanced services for a worry-free journey.',
      price: 'PKR 1,250,000',
      duration: '35-40 Days',
      image: '/images/package-standard.jpg',
      hotel: '4-star, 1-2km from Haram',
      transport: 'Semi-private AC transport',
      features: [
        'Hajj visa processing',
        'Return flights from Karachi',
        'Premium Makkah & Madinah hotels',
        'All meals included',
        'Experienced group leader',
        'Comprehensive ziyarat tours',
        'Pre-Hajj training sessions',
        '24/7 dedicated support',
      ],
      popular: true,
    },
    {
      name: 'VIP Package',
      description: 'Premium proximity, private transport, and dedicated personal guide for the ultimate experience.',
      price: 'PKR 1,850,000',
      duration: '35-40 Days',
      image: '/images/package-vip.jpg',
      hotel: '5-star, walking distance',
      transport: 'Private AC vehicle',
      features: [
        'Priority Hajj visa processing',
        'Business class flights available',
        'Luxury hotels nearest to Haram',
        'Gourmet meals & room service',
        'Dedicated personal guide',
        'Private ziyarat tours',
        'Exclusive training sessions',
        'Concierge services',
        '24/7 personal support line',
      ],
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div ref={heroRef} className="section-dark py-32 lg:py-40 relative overflow-hidden">
        <div className="geometric-pattern" />
        <div className="container-custom relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <span className="animate-item label-uppercase block mb-4">Hajj 2026</span>
            <h1 className="animate-item heading-xl text-cream mb-6">
              Hajj Packages
            </h1>
            <p className="animate-item body-text text-cream/80">
              Embark on the journey of a lifetime with our comprehensive Hajj packages. 
              Designed for comfort, guided with care.
            </p>
          </div>
        </div>
      </div>

      {/* Packages Grid */}
      <div className="section-light py-20 lg:py-28">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <PackageCard key={pkg.name} pkg={pkg} index={index} />
            ))}
          </div>

          {/* Important Notes */}
          <div className="mt-16 bg-emerald/5 rounded-2xl p-8">
            <h3 className="font-playfair font-semibold text-xl text-emerald mb-4">
              Important Information
            </h3>
            <ul className="space-y-3 text-emerald/80">
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                <span>All packages include complete Hajj rituals guidance (Manasik)</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                <span>Prices are per person based on quad sharing (twin sharing available at additional cost)</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                <span>Early booking discount available (book before Ramadan)</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                <span>Installment plans available for bookings made 6 months in advance</span>
              </li>
            </ul>
          </div>

          {/* CTA */}
          <div className="mt-12 text-center">
            <p className="text-emerald/70 mb-6">
              Have questions about our Hajj packages? We're here to help.
            </p>
            <Link to="/contact" className="btn-emerald inline-flex items-center gap-2">
              Contact Us
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HajjPackages;
