import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import HeroSection from '../sections/HeroSection';
import StatementSection from '../sections/StatementSection';
import FeatureComfortSection from '../sections/FeatureComfortSection';
import PackagesSection from '../sections/PackagesSection';
import ProcessSection from '../sections/ProcessSection';
import FeatureGuidanceSection from '../sections/FeatureGuidanceSection';
import TestimonialsSection from '../sections/TestimonialsSection';
import ContactCTASection from '../sections/ContactCTASection';

gsap.registerPlugin(ScrollTrigger);

const Home = () => {
  useEffect(() => {
    // Wait for all sections to mount and create their ScrollTriggers
    const timer = setTimeout(() => {
      // Get all pinned ScrollTriggers
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (!maxScroll || pinned.length === 0) return;

      // Build ranges and snap targets from pinned sections
      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      // Create global snap
      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            // Check if within any pinned range (allow small buffer)
            const inPinned = pinnedRanges.some(
              r => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            
            if (!inPinned) return value; // flowing section: free scroll

            // Find nearest pinned center
            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );
            
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 500);

    return () => {
      clearTimeout(timer);
      // Only kill the global snap trigger, not section triggers
      const allTriggers = ScrollTrigger.getAll();
      const globalSnap = allTriggers.find(st => !st.vars.pin && st.vars.snap);
      if (globalSnap) globalSnap.kill();
    };
  }, []);

  return (
    <div className="relative">
      {/* Section 1: Hero - z-10 */}
      <HeroSection />
      
      {/* Section 2: Statement - z-20 */}
      <StatementSection />
      
      {/* Section 3: Feature Comfort - z-30 */}
      <FeatureComfortSection />
      
      {/* Section 4: Packages Grid - z-40 (flowing) */}
      <PackagesSection />
      
      {/* Section 5: Process Timeline - z-50 (flowing) */}
      <ProcessSection />
      
      {/* Section 6: Feature Guidance - z-60 */}
      <FeatureGuidanceSection />
      
      {/* Section 7: Testimonials - z-70 (flowing) */}
      <TestimonialsSection />
      
      {/* Section 8: Contact CTA - z-80 (flowing) */}
      <ContactCTASection />
    </div>
  );
};

export default Home;
