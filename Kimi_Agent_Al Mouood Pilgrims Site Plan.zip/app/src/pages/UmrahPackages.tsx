import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Users, Calendar, Moon, Heart, ArrowRight, Star, Bed, Bus, FileText } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface UmrahPackage {
  id: string;
  name: string;
  category: string;
  description: string;
  price: string;
  duration: string;
  features: string[];
}

const UmrahPackages = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const [activeCategory, setActiveCategory] = useState('all');

  useEffect(() => {
    const hero = heroRef.current;
    if (!hero) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(hero.querySelectorAll('.animate-item'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          duration: 0.8,
          ease: 'power2.out',
        }
      );
    });

    return () => ctx.revert();
  }, []);

  const categories = [
    { id: 'all', name: 'All Packages', icon: Star },
    { id: 'family', name: 'Family', icon: Heart },
    { id: 'group', name: 'Group', icon: Users },
    { id: 'ramadan', name: 'Ramadan', icon: Moon },
  ];

  const packages: UmrahPackage[] = [
    // Family Packages
    {
      id: 'family-1',
      name: 'Family Essential',
      category: 'family',
      description: 'Perfect for small families seeking a budget-friendly Umrah experience.',
      price: 'PKR 180,000',
      duration: '7 Days',
      features: [
        '3-star hotel near Haram',
        'Visa processing',
        'Return flights',
        'Breakfast included',
        'Group transfers',
      ],
    },
    {
      id: 'family-2',
      name: 'Family Comfort',
      category: 'family',
      description: 'Enhanced comfort for families who want a stress-free journey.',
      price: 'PKR 280,000',
      duration: '10 Days',
      features: [
        '4-star hotel walking distance',
        'Visa & flights included',
        'All meals included',
        'Private family transport',
        'Kids-friendly services',
        'Ziyarat tours',
      ],
    },
    {
      id: 'family-3',
      name: 'Family Premium',
      category: 'family',
      description: 'Luxury experience for families seeking the best accommodations.',
      price: 'PKR 450,000',
      duration: '12 Days',
      features: [
        '5-star hotel nearest to Haram',
        'Business class flights option',
        'All meals & room service',
        'Private luxury transport',
        'Dedicated family guide',
        'VIP ziyarat experience',
        'Concierge services',
      ],
    },
    // Group Packages
    {
      id: 'group-1',
      name: 'Group Economy',
      category: 'group',
      description: 'Join fellow pilgrims in an affordable group Umrah experience.',
      price: 'PKR 150,000',
      duration: '7 Days',
      features: [
        '3-star hotel (4-5km)',
        'Visa processing',
        'Return flights',
        'Shared transport',
        'Group leader',
      ],
    },
    {
      id: 'group-2',
      name: 'Group Standard',
      category: 'group',
      description: 'Balanced group package with better hotels and services.',
      price: 'PKR 220,000',
      duration: '10 Days',
      features: [
        '4-star hotel (1-2km)',
        'Visa & flights included',
        'AC bus transport',
        'All meals included',
        'Experienced group leader',
        'Ziyarat tours',
      ],
    },
    {
      id: 'group-3',
      name: 'Group Deluxe',
      category: 'group',
      description: 'Premium group experience with superior accommodations.',
      price: 'PKR 350,000',
      duration: '12 Days',
      features: [
        '5-star hotel walking distance',
        'Premium flights',
        'Luxury coach transport',
        'Gourmet meals',
        'Scholar-led guidance',
        'Comprehensive ziyarat',
      ],
    },
    // Ramadan Packages
    {
      id: 'ramadan-1',
      name: 'Ramadan First Ashra',
      category: 'ramadan',
      description: 'Experience the blessed first ten days of Ramadan in Makkah.',
      price: 'PKR 320,000',
      duration: '10 Days',
      features: [
        '4-star hotel near Haram',
        'Visa & flights included',
        'Suhoor & Iftar arranged',
        'Taraweeh guidance',
        'Daily iftar gatherings',
      ],
    },
    {
      id: 'ramadan-2',
      name: 'Ramadan Last Ashra',
      category: 'ramadan',
      description: 'The most sought-after package for Laylatul Qadr.',
      price: 'PKR 380,000',
      duration: '12 Days',
      features: [
        '4-star hotel walking distance',
        'Visa & flights included',
        'All meals included',
        'Special Itikaf arrangements',
        'Night prayers guidance',
        'Eid in Makkah',
      ],
    },
    {
      id: 'ramadan-3',
      name: 'Full Ramadan',
      category: 'ramadan',
      description: 'Complete Ramadan experience from beginning to Eid.',
      price: 'PKR 850,000',
      duration: '30 Days',
      features: [
        '4-star hotel throughout',
        'Visa & flights included',
        'All meals & iftar parties',
        'Daily religious programs',
        'Itikaf support',
        'Eid arrangements',
        'Madinah visit included',
      ],
    },
  ];

  const filteredPackages = activeCategory === 'all' 
    ? packages 
    : packages.filter(pkg => pkg.category === activeCategory);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div ref={heroRef} className="section-dark py-32 lg:py-40 relative overflow-hidden">
        <div className="geometric-pattern" />
        <div className="container-custom relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <span className="animate-item label-uppercase block mb-4">Umrah Packages</span>
            <h1 className="animate-item heading-xl text-cream mb-6">
              Choose Your Spiritual Journey
            </h1>
            <p className="animate-item body-text text-cream/80">
              From family packages to group departures and blessed Ramadan experiences, 
              find the perfect Umrah package for you.
            </p>
          </div>
        </div>
      </div>

      {/* Packages Section */}
      <div className="section-light py-20 lg:py-28">
        <div className="container-custom">
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((cat) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all ${
                    activeCategory === cat.id
                      ? 'bg-emerald text-cream'
                      : 'bg-emerald/10 text-emerald hover:bg-emerald/20'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {cat.name}
                </button>
              );
            })}
          </div>

          {/* Packages Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPackages.map((pkg) => (
              <div
                key={pkg.id}
                className="bg-cream rounded-xl overflow-hidden shadow-soft card-hover border border-emerald/10"
              >
                {/* Header */}
                <div className="bg-emerald/5 p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium uppercase tracking-wider text-gold">
                      {categories.find(c => c.id === pkg.category)?.name}
                    </span>
                    <div className="flex items-center gap-1 text-emerald/60 text-sm">
                      <Calendar className="w-4 h-4" />
                      {pkg.duration}
                    </div>
                  </div>
                  <h3 className="font-playfair font-semibold text-xl text-emerald">
                    {pkg.name}
                  </h3>
                </div>

                {/* Content */}
                <div className="p-6">
                  <p className="text-emerald/70 text-sm mb-4">
                    {pkg.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-2 mb-6">
                    {pkg.features.slice(0, 4).map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-emerald/80">
                        <Check className="w-4 h-4 text-gold flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                    {pkg.features.length > 4 && (
                      <li className="text-sm text-emerald/50">
                        +{pkg.features.length - 4} more features
                      </li>
                    )}
                  </ul>

                  {/* Price & CTA */}
                  <div className="flex items-center justify-between pt-4 border-t border-emerald/10">
                    <div>
                      <span className="text-xs text-emerald/50">Starting from</span>
                      <p className="text-xl font-playfair font-bold text-gold">{pkg.price}</p>
                    </div>
                    <Link
                      to="/contact"
                      className="inline-flex items-center gap-1 text-emerald font-medium hover:text-gold transition-colors"
                    >
                      Book Now
                      <ArrowRight className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Custom Package CTA */}
          <div className="mt-16 text-center bg-emerald rounded-2xl p-8 lg:p-12 relative overflow-hidden">
            <div className="geometric-pattern" />
            <div className="relative z-10">
              <h3 className="font-playfair font-semibold text-2xl text-cream mb-4">
                Need a Custom Package?
              </h3>
              <p className="text-cream/80 mb-6 max-w-xl mx-auto">
                We can create a personalized Umrah package tailored to your specific needs, 
                dates, and preferences.
              </p>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 bg-gold text-emerald px-8 py-3 rounded-full font-medium hover:bg-gold-light transition-colors"
              >
                Request Custom Quote
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>

          {/* Features Overview */}
          <div className="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Bed, title: 'Quality Hotels', desc: 'Carefully selected accommodations' },
              { icon: Bus, title: 'Reliable Transport', desc: 'Comfortable air-conditioned vehicles' },
              { icon: FileText, title: 'Visa Assistance', desc: 'Complete documentation support' },
              { icon: Users, title: 'Expert Guides', desc: 'Experienced religious guides' },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.title} className="text-center">
                  <div className="w-14 h-14 rounded-full bg-emerald/10 flex items-center justify-center mx-auto mb-3">
                    <Icon className="w-6 h-6 text-emerald" />
                  </div>
                  <h4 className="font-medium text-emerald mb-1">{item.title}</h4>
                  <p className="text-sm text-emerald/60">{item.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UmrahPackages;
