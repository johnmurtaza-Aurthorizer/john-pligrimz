import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Heart, Shield, Users, Star, Target, Compass } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const About = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const valuesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const hero = heroRef.current;
    const content = contentRef.current;
    const values = valuesRef.current;

    if (!hero || !content || !values) return;

    const ctx = gsap.context(() => {
      // Hero animation
      gsap.fromTo(hero.querySelectorAll('.animate-item'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          duration: 0.8,
          ease: 'power2.out',
        }
      );

      // Content animation
      gsap.fromTo(content.children,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.15,
          scrollTrigger: {
            trigger: content,
            start: 'top 75%',
            end: 'top 40%',
            scrub: true,
          }
        }
      );

      // Values animation
      const valueCards = values.querySelectorAll('.value-card');
      valueCards.forEach((card, index) => {
        gsap.fromTo(card,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            delay: index * 0.1,
            scrollTrigger: {
              trigger: card,
              start: 'top 80%',
              end: 'top 60%',
              scrub: true,
            }
          }
        );
      });
    });

    return () => ctx.revert();
  }, []);

  const values = [
    {
      icon: Heart,
      title: 'Faith-Centered',
      description: 'We honor the spiritual significance of every pilgrimage, ensuring our services align with Islamic values.',
    },
    {
      icon: Shield,
      title: 'Trust & Transparency',
      description: 'Clear pricing, honest communication, and no hidden costs—ever.',
    },
    {
      icon: Users,
      title: 'Family-First',
      description: 'We understand traveling with family. Our packages are designed for comfort and convenience.',
    },
    {
      icon: Star,
      title: 'Excellence',
      description: 'From visa processing to hotel selection, we strive for excellence in every detail.',
    },
    {
      icon: Target,
      title: 'Commitment',
      description: 'We stay with you throughout your journey, providing 24/7 support.',
    },
    {
      icon: Compass,
      title: 'Guidance',
      description: 'Our experienced team provides practical and spiritual guidance every step of the way.',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div ref={heroRef} className="section-dark py-32 lg:py-40 relative overflow-hidden">
        <div className="geometric-pattern" />
        <div className="container-custom relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <span className="animate-item label-uppercase block mb-4">About Us</span>
            <h1 className="animate-item heading-xl text-cream mb-6">
              Your Trusted Partner in Spiritual Journeys
            </h1>
            <p className="animate-item body-text text-cream/80">
              Since 2010, Al Mouood Pilgrims has been serving families across Pakistan 
              with heartfelt dedication and professional excellence.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="section-light py-20 lg:py-28">
        <div className="container-custom">
          <div ref={contentRef} className="max-w-4xl mx-auto">
            {/* Company Introduction */}
            <div className="mb-16">
              <h2 className="heading-md text-emerald mb-6">Our Story</h2>
              <p className="body-text text-emerald/80 mb-6">
                Al Mouood Pilgrims was founded with a simple yet profound mission: to make the sacred 
                journeys of Hajj and Umrah accessible, comfortable, and spiritually fulfilling for 
                every Muslim family in Pakistan.
              </p>
              <p className="body-text text-emerald/80 mb-6">
                What started as a small family business in Karachi has grown into one of the most 
                trusted names in pilgrimage travel. Over the years, we have had the privilege of 
                serving thousands of pilgrims, each journey reinforcing our commitment to excellence 
                and compassion.
              </p>
              <p className="body-text text-emerald/80">
                Based in the heart of Karachi, we understand the needs of Pakistani families. 
                Our team speaks your language, understands your concerns, and is dedicated to 
                making your pilgrimage as smooth as possible.
              </p>
            </div>

            {/* Mission & Vision */}
            <div className="grid md:grid-cols-2 gap-8 mb-16">
              <div className="bg-emerald/5 p-8 rounded-xl">
                <h3 className="font-playfair font-semibold text-xl text-emerald mb-4">
                  Our Mission
                </h3>
                <p className="text-emerald/80">
                  To provide every pilgrim with a seamless, spiritually enriching journey 
                  through exceptional service, transparent dealings, and unwavering support.
                </p>
              </div>
              <div className="bg-emerald/5 p-8 rounded-xl">
                <h3 className="font-playfair font-semibold text-xl text-emerald mb-4">
                  Our Vision
                </h3>
                <p className="text-emerald/80">
                  To be the most trusted and respected pilgrimage travel agency in Pakistan, 
                  known for our integrity, excellence, and genuine care for every pilgrim.
                </p>
              </div>
            </div>

            {/* Commitment */}
            <div className="mb-16">
              <h2 className="heading-md text-emerald mb-6">Our Commitment to You</h2>
              <p className="body-text text-emerald/80 mb-6">
                At Al Mouood Pilgrims, we believe that preparing for Hajj or Umrah should be 
                a time of spiritual anticipation, not logistical stress. That's why we handle 
                every detail—from visa processing and flight bookings to hotel accommodations 
                and ground transportation.
              </p>
              <p className="body-text text-emerald/80">
                Our commitment extends beyond logistics. We provide pre-departure briefings, 
                daily guidance during your journey, and 24/7 support to ensure you can focus 
                entirely on your ibadah. Our guides are experienced, knowledgeable, and 
                respectful of the spiritual significance of every moment.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Values Section */}
      <div className="section-dark py-20 lg:py-28 relative overflow-hidden">
        <div className="geometric-pattern" />
        <div className="container-custom relative z-10">
          <div className="text-center mb-16">
            <span className="label-uppercase block mb-4">Our Values</span>
            <h2 className="heading-lg text-cream mb-4">
              What We Stand For
            </h2>
          </div>

          <div ref={valuesRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {values.map((value) => {
              const Icon = value.icon;
              return (
                <div
                  key={value.title}
                  className="value-card bg-cream/5 backdrop-blur-sm border border-cream/10 p-8 rounded-xl hover:bg-cream/10 transition-colors"
                >
                  <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-gold" />
                  </div>
                  <h3 className="font-playfair font-semibold text-lg text-cream mb-3">
                    {value.title}
                  </h3>
                  <p className="text-cream/70 text-sm">
                    {value.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="section-light py-20 lg:py-28">
        <div className="container-custom">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { number: '15+', label: 'Years of Experience' },
              { number: '5000+', label: 'Pilgrims Served' },
              { number: '98%', label: 'Customer Satisfaction' },
              { number: '24/7', label: 'Support Available' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-4xl lg:text-5xl font-playfair font-bold text-gold mb-2">
                  {stat.number}
                </div>
                <div className="text-emerald/70 text-sm">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
