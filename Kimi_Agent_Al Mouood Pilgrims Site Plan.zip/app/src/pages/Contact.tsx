import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Phone, Mail, Clock, MessageCircle, Send, Check } from 'lucide-react';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

const Contact = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    package: '',
    message: '',
  });

  useEffect(() => {
    const hero = heroRef.current;
    const form = formRef.current;
    const info = infoRef.current;

    if (!hero || !form || !info) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(hero.querySelectorAll('.animate-item'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          duration: 0.8,
          ease: 'power2.out',
        }
      );

      gsap.fromTo(form,
        { x: 40, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: form,
            start: 'top 80%',
            end: 'top 50%',
            scrub: true,
          }
        }
      );

      gsap.fromTo(info,
        { x: -40, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: info,
            start: 'top 80%',
            end: 'top 50%',
            scrub: true,
          }
        }
      );
    });

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Thank you for your inquiry! We will contact you within 24 hours.');
    setFormData({ name: '', phone: '', email: '', package: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: 'Visit Us',
      content: 'G-03, Ground Floor, Al-Najaf Arcade, 3 Road side, opposite Jiwani Homes, near KMC Market, Soldier Bazaar Garden East, Karachi, 75050',
      link: 'https://maps.google.com/?q=V2HM+43+Garden+East+Karachi+Pakistan',
    },
    {
      icon: Phone,
      title: 'Call Us',
      content: '+92 335 2200014',
      link: 'tel:+923352200014',
    },
    {
      icon: Mail,
      title: 'Email Us',
      content: 'info@almouood.com',
      link: 'mailto:info@almouood.com',
    },
    {
      icon: Clock,
      title: 'Working Hours',
      content: 'Opens 11 AM - Monday to Saturday',
      link: null,
    },
  ];

  const whatsappUrl = `https://wa.me/+923352200014?text=${encodeURIComponent('Assalamualaikum! I would like to inquire about your Hajj/Umrah packages.')}`;

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div ref={heroRef} className="section-dark py-32 lg:py-40 relative overflow-hidden">
        <div className="geometric-pattern" />
        <div className="container-custom relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <span className="animate-item label-uppercase block mb-4">Contact Us</span>
            <h1 className="animate-item heading-xl text-cream mb-6">
              Get in Touch
            </h1>
            <p className="animate-item body-text text-cream/80">
              Have questions about our packages? We're here to help you plan your spiritual journey.
            </p>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="section-light py-20 lg:py-28">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
            {/* Left Column - Contact Info */}
            <div ref={infoRef}>
              <h2 className="heading-md text-emerald mb-8">
                Contact Information
              </h2>

              <div className="space-y-6 mb-10">
                {contactInfo.map((item) => {
                  const Icon = item.icon;
                  const content = (
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-full bg-emerald/10 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-emerald" />
                      </div>
                      <div>
                        <h4 className="font-medium text-emerald mb-1">{item.title}</h4>
                        <p className="text-emerald/70 text-sm">{item.content}</p>
                      </div>
                    </div>
                  );

                  return item.link ? (
                    <a
                      key={item.title}
                      href={item.link}
                      target={item.link.startsWith('http') ? '_blank' : undefined}
                      rel={item.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                      className="block hover:bg-emerald/5 p-4 -m-4 rounded-xl transition-colors"
                    >
                      {content}
                    </a>
                  ) : (
                    <div key={item.title} className="p-4 -m-4">
                      {content}
                    </div>
                  );
                })}
              </div>

              {/* WhatsApp CTA */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 bg-green-500 text-white px-6 py-3 rounded-full font-medium hover:bg-green-600 transition-all duration-300 hover:-translate-y-0.5"
              >
                <MessageCircle className="w-5 h-5" />
                Chat on WhatsApp
              </a>
            </div>

            {/* Right Column - Form */}
            <div ref={formRef}>
              <div className="bg-cream rounded-2xl p-8 shadow-card border border-emerald/10">
                <h3 className="font-playfair font-semibold text-xl text-emerald mb-2">
                  Send an Inquiry
                </h3>
                <p className="text-emerald/70 text-sm mb-6">
                  Fill out the form below and we'll get back to you within 24 hours.
                </p>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-emerald mb-2">
                        Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald placeholder:text-emerald/40 focus:outline-none focus:border-gold transition-colors"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-emerald mb-2">
                        Phone *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald placeholder:text-emerald/40 focus:outline-none focus:border-gold transition-colors"
                        placeholder="+92 3XX XXXXXXX"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-emerald mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald placeholder:text-emerald/40 focus:outline-none focus:border-gold transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-emerald mb-2">
                      Interested Package
                    </label>
                    <select
                      name="package"
                      value={formData.package}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald focus:outline-none focus:border-gold transition-colors"
                    >
                      <option value="">Select a package</option>
                      <option value="hajj-economy">Hajj Economy</option>
                      <option value="hajj-standard">Hajj Standard</option>
                      <option value="hajj-vip">Hajj VIP</option>
                      <option value="umrah-family">Umrah Family</option>
                      <option value="umrah-group">Umrah Group</option>
                      <option value="umrah-ramadan">Umrah Ramadan</option>
                      <option value="custom">Custom Package</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-emerald mb-2">
                      Message
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={4}
                      className="w-full px-4 py-3 rounded-lg border border-emerald/20 bg-white text-emerald placeholder:text-emerald/40 focus:outline-none focus:border-gold transition-colors resize-none"
                      placeholder="Tell us about your preferred dates, number of travelers, and any special requirements..."
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gold text-emerald py-3 rounded-full font-medium flex items-center justify-center gap-2 hover:bg-gold-dark transition-colors"
                  >
                    <Send className="w-4 h-4" />
                    Send Inquiry
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Map Section */}
      <div className="section-dark py-20 lg:py-28 relative overflow-hidden">
        <div className="geometric-pattern" />
        <div className="container-custom relative z-10">
          <div className="text-center mb-12">
            <h2 className="heading-md text-cream mb-4">
              Find Us
            </h2>
            <p className="body-text text-cream/70 max-w-xl mx-auto">
              Visit our office in Karachi to discuss your pilgrimage plans in person.
            </p>
          </div>

          {/* Google Maps Embed */}
          <div className="rounded-2xl overflow-hidden shadow-card">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3620.1234567890123!2d67.02812345678901!3d24.861234567890123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjTCsDUxJzQwLjQiTiA2N8KwMDEnNDEuMiJF!5e0!3m2!1sen!2s!4v1234567890123!5m2!1sen!2s"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Al Mouood Pilgrims Location"
              className="grayscale-[20%]"
            />
          </div>

          {/* Address Card */}
          <div className="mt-8 bg-cream/5 backdrop-blur-sm border border-cream/10 rounded-xl p-6 max-w-2xl mx-auto">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h4 className="font-playfair font-semibold text-lg text-cream mb-2">
                  Al Mouood Pilgrims
                </h4>
                <p className="text-cream/70 text-sm">
                  G-03, Ground Floor, Al-Najaf Arcade (النجف آرکیڈ), 3 Road side, 
                  opposite Jiwani Homes, near KMC Market, Soldier Bazaar Garden East, 
                  Karachi, 75050, Pakistan
                </p>
                <p className="text-cream/50 text-sm mt-2">
                  Google Maps Code: V2HM+43 Garden East, Karachi, Pakistan
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="section-light py-20 lg:py-28">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="heading-md text-emerald mb-4">
              Frequently Asked Questions
            </h2>
            <p className="body-text text-emerald/70 max-w-xl mx-auto">
              Find answers to common questions about Hajj and Umrah
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {[
              {
                q: 'What documents are required for Umrah visa?',
                a: 'You need a valid passport (6+ months), 2 passport-sized photos with white background, CNIC copy, and vaccination certificate.',
              },
              {
                q: 'How early should I book for Hajj?',
                a: 'We recommend booking at least 6-8 months in advance, as Hajj visas are limited and processed on a first-come basis.',
              },
              {
                q: 'Are your packages suitable for elderly pilgrims?',
                a: 'Yes, we offer special arrangements for elderly pilgrims including wheelchair assistance, ground-floor rooms, and dedicated care.',
              },
              {
                q: 'Can I customize my package?',
                a: 'Absolutely! We can customize packages based on your preferred dates, hotel choices, and additional services.',
              },
              {
                q: 'What is included in the package price?',
                a: 'Our packages typically include visa, flights, accommodation, meals, transport, and guided ziyarat tours.',
              },
              {
                q: 'Do you offer installment plans?',
                a: 'Yes, we offer flexible installment plans for bookings made at least 6 months in advance.',
              },
            ].map((faq, index) => (
              <div key={index} className="bg-cream rounded-xl p-6 shadow-soft border border-emerald/10">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <Check className="w-3 h-3 text-gold" />
                  </div>
                  <div>
                    <h4 className="font-medium text-emerald mb-2">{faq.q}</h4>
                    <p className="text-emerald/70 text-sm">{faq.a}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
