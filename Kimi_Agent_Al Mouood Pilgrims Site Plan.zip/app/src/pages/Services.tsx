import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  FileText, 
  Plane, 
  Hotel, 
  MapPin, 
  Shield, 
  HeadphonesIcon,
  ArrowRight,
  Check
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ServiceProps {
  icon: React.ElementType;
  title: string;
  description: string;
  features: string[];
}

const ServiceCard = ({ service, index }: { service: ServiceProps; index: number }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const Icon = service.icon;

  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(card,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          delay: index * 0.1,
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          }
        }
      );
    }, card);

    return () => ctx.revert();
  }, [index]);

  return (
    <div
      ref={cardRef}
      className="bg-cream rounded-2xl p-8 shadow-soft card-hover border border-emerald/10"
    >
      {/* Icon */}
      <div className="w-16 h-16 rounded-full bg-emerald/10 flex items-center justify-center mb-6">
        <Icon className="w-8 h-8 text-emerald" />
      </div>

      {/* Content */}
      <h3 className="font-playfair font-semibold text-xl text-emerald mb-3">
        {service.title}
      </h3>
      <p className="text-emerald/70 mb-6">
        {service.description}
      </p>

      {/* Features */}
      <ul className="space-y-2">
        {service.features.map((feature, idx) => (
          <li key={idx} className="flex items-center gap-2 text-sm text-emerald/80">
            <Check className="w-4 h-4 text-gold flex-shrink-0" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

const Services = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const hero = heroRef.current;
    if (!hero) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(hero.querySelectorAll('.animate-item'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          duration: 0.8,
          ease: 'power2.out',
        }
      );
    });

    return () => ctx.revert();
  }, []);

  const services: ServiceProps[] = [
    {
      icon: FileText,
      title: 'Hajj & Umrah Visa Processing',
      description: 'Complete visa assistance with document preparation, submission, and tracking.',
      features: [
        'Document checklist guidance',
        'Application form filling',
        'Photo specifications',
        'Passport validity check',
        'Visa status tracking',
        'Express processing available',
      ],
    },
    {
      icon: Plane,
      title: 'Flight Booking',
      description: 'Best flight options with competitive rates and convenient schedules.',
      features: [
        'Multiple airline options',
        'Group bookings',
        'Flexible dates',
        'Direct & connecting flights',
        'Seat selection assistance',
        'Special meal requests',
      ],
    },
    {
      icon: Hotel,
      title: 'Hotel Accommodation',
      description: 'Carefully selected hotels in Makkah and Madinah for every budget.',
      features: [
        'Hotels near Haram',
        '3-star to 5-star options',
        'Family rooms available',
        'Breakfast included',
        'Room service options',
        'Accessibility features',
      ],
    },
    {
      icon: MapPin,
      title: 'Ziyarat Tours',
      description: 'Guided tours to historical and religious sites in both holy cities.',
      features: [
        'Makkah ziyarat (Jabal Nur, Arafat, Mina)',
        'Madinah ziyarat (Masjid Quba, Uhud, Baqi)',
        'Knowledgeable guides',
        'Air-conditioned transport',
        'Flexible schedules',
        'Private tours available',
      ],
    },
    {
      icon: Shield,
      title: 'Travel Insurance',
      description: 'Comprehensive travel insurance for peace of mind during your journey.',
      features: [
        'Medical coverage',
        'Trip cancellation protection',
        'Baggage loss coverage',
        'Emergency evacuation',
        '24/7 assistance hotline',
        'Family plans available',
      ],
    },
    {
      icon: HeadphonesIcon,
      title: '24/7 Customer Assistance',
      description: 'Round-the-clock support before, during, and after your pilgrimage.',
      features: [
        'Pre-departure briefings',
        'Airport assistance',
        'Hotel check-in support',
        'Daily guidance',
        'Emergency contact',
        'Multilingual support',
      ],
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div ref={heroRef} className="section-dark py-32 lg:py-40 relative overflow-hidden">
        <div className="geometric-pattern" />
        <div className="container-custom relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <span className="animate-item label-uppercase block mb-4">Our Services</span>
            <h1 className="animate-item heading-xl text-cream mb-6">
              Complete Pilgrimage Solutions
            </h1>
            <p className="animate-item body-text text-cream/80">
              From visa processing to 24/7 support, we handle every aspect of your 
              journey so you can focus on your spiritual experience.
            </p>
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <div className="section-light py-20 lg:py-28">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {services.map((service, index) => (
              <ServiceCard key={service.title} service={service} index={index} />
            ))}
          </div>

          {/* Why Choose Us */}
          <div className="mt-20">
            <div className="text-center mb-12">
              <h2 className="heading-md text-emerald mb-4">
                Why Choose Our Services?
              </h2>
              <p className="body-text text-emerald/70 max-w-xl mx-auto">
                We go above and beyond to ensure your pilgrimage is smooth, comfortable, and spiritually fulfilling.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  title: '15+ Years Experience',
                  description: 'Trusted by thousands of pilgrims since 2010',
                },
                {
                  title: 'Licensed & Certified',
                  description: 'Approved by Ministry of Religious Affairs',
                },
                {
                  title: 'Transparent Pricing',
                  description: 'No hidden costs or surprise charges',
                },
                {
                  title: 'Dedicated Support',
                  description: 'Personal assistance throughout your journey',
                },
              ].map((item) => (
                <div key={item.title} className="text-center p-6">
                  <div className="w-12 h-12 rounded-full bg-gold/20 flex items-center justify-center mx-auto mb-4">
                    <Check className="w-6 h-6 text-gold" />
                  </div>
                  <h4 className="font-playfair font-semibold text-lg text-emerald mb-2">
                    {item.title}
                  </h4>
                  <p className="text-sm text-emerald/70">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div className="mt-16 text-center">
            <p className="text-emerald/70 mb-6">
              Ready to start your journey? Get in touch with us today.
            </p>
            <Link to="/contact" className="btn-emerald inline-flex items-center gap-2">
              Contact Us
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>

      {/* Process Section */}
      <div className="section-dark py-20 lg:py-28 relative overflow-hidden">
        <div className="geometric-pattern" />
        <div className="container-custom relative z-10">
          <div className="text-center mb-12">
            <h2 className="heading-md text-cream mb-4">
              How It Works
            </h2>
            <p className="body-text text-cream/70 max-w-xl mx-auto">
              Simple steps to begin your spiritual journey
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: '01', title: 'Inquiry', desc: 'Contact us with your preferred dates' },
              { step: '02', title: 'Consultation', desc: 'We discuss options and customize' },
              { step: '03', title: 'Booking', desc: 'Confirm with deposit payment' },
              { step: '04', title: 'Preparation', desc: 'We handle all arrangements' },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-16 h-16 rounded-full bg-gold/20 flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-playfair font-bold text-gold">{item.step}</span>
                </div>
                <h4 className="font-playfair font-semibold text-lg text-cream mb-2">
                  {item.title}
                </h4>
                <p className="text-sm text-cream/70">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
